#!/usr/bin/env python
import time

if __name__ == "__main__":
    while 1:
        time.sleep(10)
